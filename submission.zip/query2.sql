select count(*) numUsersFromNewYork from person 
where location = "New York";